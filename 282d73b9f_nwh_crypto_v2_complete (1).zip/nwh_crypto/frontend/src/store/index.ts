/**
 * Global state management using Zustand
 */
import { create } from 'zustand'
import { devtools, persist } from 'zustand/middleware'

// ─── Types ───────────────────────────────────────────────

export interface User {
  id: string
  email: string
  username: string
  full_name?: string
  role: 'admin' | 'trader' | 'viewer'
  two_fa_enabled: boolean
  preferred_language: 'en' | 'fa'
}

export interface Position {
  id: string
  symbol: string
  direction: 'long' | 'short'
  entry_price: number
  current_price: number
  quantity: number
  unrealized_pnl: number
  unrealized_pnl_percent: number
  stop_loss: number
  take_profit_1?: number
  opened_at: string
}

export interface Trade {
  id: string
  symbol: string
  direction: 'long' | 'short'
  entry_price: number
  exit_price?: number
  quantity: number
  pnl?: number
  pnl_percent?: number
  status: string
  trading_mode: 'live' | 'paper' | 'backtest'
  opened_at: string
  closed_at?: string
  exit_reason?: string
}

export interface RiskStatus {
  trading_halted: boolean
  halt_reason?: string
  daily_drawdown_percent: number
  open_trades: number
  max_simultaneous_trades: number
  daily_pnl: number
  daily_pnl_percent: number
}

export interface MarketTicker {
  symbol: string
  last: number
  bid: number
  ask: number
  volume: number
  change_percent: number
}

// ─── Auth Store ───────────────────────────────────────────

interface AuthState {
  user: User | null
  accessToken: string | null
  refreshToken: string | null
  isAuthenticated: boolean
  setAuth: (user: User, accessToken: string, refreshToken: string) => void
  clearAuth: () => void
  updateUser: (updates: Partial<User>) => void
}

export const useAuthStore = create<AuthState>()(
  devtools(
    persist(
      (set) => ({
        user: null,
        accessToken: null,
        refreshToken: null,
        isAuthenticated: false,

        setAuth: (user, accessToken, refreshToken) =>
          set({ user, accessToken, refreshToken, isAuthenticated: true }),

        clearAuth: () =>
          set({ user: null, accessToken: null, refreshToken: null, isAuthenticated: false }),

        updateUser: (updates) =>
          set((state) => ({ user: state.user ? { ...state.user, ...updates } : null })),
      }),
      { name: 'nwh-auth', partialize: (state) => ({ accessToken: state.accessToken, refreshToken: state.refreshToken }) }
    )
  )
)

// ─── Trading Store ────────────────────────────────────────

interface TradingState {
  positions: Position[]
  trades: Trade[]
  riskStatus: RiskStatus | null
  tickers: Record<string, MarketTicker>
  tradingMode: 'live' | 'paper'
  selectedExchange: string
  paperBalance: number

  setPositions: (positions: Position[]) => void
  updatePosition: (id: string, updates: Partial<Position>) => void
  removePosition: (id: string) => void
  addTrade: (trade: Trade) => void
  setTrades: (trades: Trade[]) => void
  setRiskStatus: (status: RiskStatus) => void
  updateTicker: (symbol: string, ticker: MarketTicker) => void
  setTradingMode: (mode: 'live' | 'paper') => void
  setSelectedExchange: (exchange: string) => void
  setPaperBalance: (balance: number) => void
}

export const useTradingStore = create<TradingState>()(
  devtools((set) => ({
    positions: [],
    trades: [],
    riskStatus: null,
    tickers: {},
    tradingMode: 'paper',
    selectedExchange: 'binance',
    paperBalance: 10000,

    setPositions: (positions) => set({ positions }),
    updatePosition: (id, updates) =>
      set((state) => ({
        positions: state.positions.map((p) => (p.id === id ? { ...p, ...updates } : p)),
      })),
    removePosition: (id) =>
      set((state) => ({ positions: state.positions.filter((p) => p.id !== id) })),
    addTrade: (trade) =>
      set((state) => ({ trades: [trade, ...state.trades].slice(0, 200) })),
    setTrades: (trades) => set({ trades }),
    setRiskStatus: (riskStatus) => set({ riskStatus }),
    updateTicker: (symbol, ticker) =>
      set((state) => ({ tickers: { ...state.tickers, [symbol]: ticker } })),
    setTradingMode: (tradingMode) => set({ tradingMode }),
    setSelectedExchange: (selectedExchange) => set({ selectedExchange }),
    setPaperBalance: (paperBalance) => set({ paperBalance }),
  }))
)

// ─── UI Store ─────────────────────────────────────────────

interface UIState {
  theme: 'dark' | 'light'
  language: 'en' | 'fa'
  sidebarOpen: boolean
  activeNotifications: number
  toggleTheme: () => void
  setLanguage: (lang: 'en' | 'fa') => void
  toggleSidebar: () => void
  setNotificationCount: (count: number) => void
}

export const useUIStore = create<UIState>()(
  devtools(
    persist(
      (set) => ({
        theme: 'dark',
        language: 'en',
        sidebarOpen: true,
        activeNotifications: 0,

        toggleTheme: () => set((state) => ({ theme: state.theme === 'dark' ? 'light' : 'dark' })),
        setLanguage: (language) => set({ language }),
        toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
        setNotificationCount: (count) => set({ activeNotifications: count }),
      }),
      { name: 'nwh-ui' }
    )
  )
)
