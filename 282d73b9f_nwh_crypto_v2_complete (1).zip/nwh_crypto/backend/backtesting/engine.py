"""
Backtesting Engine
Historical strategy testing with full performance analytics.
Supports: equity curve, drawdown, Sharpe ratio, multi-strategy comparison.
"""
import asyncio
import numpy as np
import pandas as pd
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from ..core.logging import get_logger
from ..strategies.base_strategy import BaseStrategy, SignalType
from ..risk_engine.models import TradeSignal

logger = get_logger(__name__)


@dataclass
class BacktestConfig:
    strategy: BaseStrategy
    symbol: str
    timeframe: str
    start_date: str  # ISO format
    end_date: str
    initial_balance: float = 10000.0
    commission_percent: float = 0.1  # 0.1%
    slippage_percent: float = 0.05   # 0.05%
    risk_per_trade_percent: float = 1.0
    use_risk_engine: bool = True


@dataclass
class BacktestTradeResult:
    symbol: str
    direction: str
    entry_price: float
    exit_price: float
    quantity: float
    entry_time: str
    exit_time: str
    stop_loss: float
    take_profit: Optional[float]
    pnl: float
    pnl_percent: float
    fees: float
    exit_reason: str
    indicators: Dict = field(default_factory=dict)


@dataclass
class BacktestResult:
    strategy_name: str
    symbol: str
    timeframe: str
    start_date: str
    end_date: str
    initial_balance: float
    final_balance: float
    total_return_percent: float
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    profit_factor: float
    sharpe_ratio: float
    sortino_ratio: float
    calmar_ratio: float
    max_drawdown_percent: float
    max_drawdown_duration_days: int
    avg_trade_duration_hours: float
    avg_win: float
    avg_loss: float
    best_trade: float
    worst_trade: float
    total_fees: float
    trades: List[BacktestTradeResult]
    equity_curve: List[Dict]
    drawdown_curve: List[Dict]


class BacktestEngine:
    """
    Professional backtesting engine with realistic simulation.
    
    Features:
    - Commission and slippage modeling
    - Multi-level take profit
    - Trailing stop simulation
    - Sharpe, Sortino, Calmar ratios
    - Drawdown analysis
    - Equity curve generation
    """

    def __init__(self, config: BacktestConfig):
        self.config = config

    async def run(self, candles: List[Dict]) -> BacktestResult:
        """
        Run backtest on historical candle data.
        
        Args:
            candles: Full historical OHLCV data
        
        Returns:
            Complete BacktestResult with all metrics
        """
        logger.info(f"Starting backtest: {self.config.strategy.name} on {self.config.symbol} [{self.config.timeframe}]")

        strategy = self.config.strategy
        balance = self.config.initial_balance
        equity_curve = [{"time": candles[0].get("timestamp", 0), "balance": balance}]
        trades: List[BacktestTradeResult] = []

        required = strategy.get_required_candles()
        open_position: Optional[Dict] = None

        for i in range(required, len(candles)):
            window = candles[:i + 1]
            current_candle = candles[i]
            current_close = float(current_candle["close"])
            current_high = float(current_candle["high"])
            current_low = float(current_candle["low"])
            timestamp = current_candle.get("timestamp", i)

            # Check open position SL/TP
            if open_position:
                exit_price, exit_reason = self._check_exit(
                    open_position, current_high, current_low, current_close
                )
                if exit_price:
                    trade = self._close_position(open_position, exit_price, exit_reason, str(timestamp))
                    trades.append(trade)
                    balance += trade.pnl - trade.fees
                    open_position = None
                    equity_curve.append({"time": timestamp, "balance": round(balance, 2)})
                    continue

            # Generate signal
            signal = await strategy.on_candle(self.config.symbol, current_candle)

            if signal and signal.signal_type in [SignalType.BUY, SignalType.SELL] and not open_position:
                if signal.stop_loss is None:
                    continue  # No SL = no trade

                direction = "long" if signal.signal_type == SignalType.BUY else "short"

                # Simulate slippage
                slippage_factor = 1 + (self.config.slippage_percent / 100)
                entry_price = current_close * slippage_factor if direction == "long" else current_close / slippage_factor

                # Position sizing
                risk_amount = balance * (self.config.risk_per_trade_percent / 100)
                sl_distance = abs(entry_price - signal.stop_loss)
                if sl_distance == 0:
                    continue

                quantity = risk_amount / sl_distance
                position_value = quantity * entry_price

                if position_value > balance * 0.95:
                    continue  # Would use too much balance

                fee = position_value * (self.config.commission_percent / 100)
                balance -= fee

                open_position = {
                    "direction": direction,
                    "entry_price": entry_price,
                    "quantity": quantity,
                    "stop_loss": signal.stop_loss,
                    "take_profit_1": signal.take_profit_1,
                    "take_profit_2": signal.take_profit_2,
                    "take_profit_3": signal.take_profit_3,
                    "entry_time": str(timestamp),
                    "fee_paid": fee,
                    "indicators": signal.indicators,
                }

            equity_curve.append({"time": timestamp, "balance": round(balance, 2)})

        # Force close any open position at end
        if open_position:
            last_price = float(candles[-1]["close"])
            trade = self._close_position(open_position, last_price, "end_of_test", str(candles[-1].get("timestamp", 0)))
            trades.append(trade)
            balance += trade.pnl - trade.fees

        return self._calculate_metrics(balance, trades, equity_curve)

    def _check_exit(self, pos: Dict, high: float, low: float, close: float):
        """Check if position should be closed on current candle."""
        direction = pos["direction"]

        if direction == "long":
            if low <= pos["stop_loss"]:
                return pos["stop_loss"], "stop_loss"
            if pos.get("take_profit_3") and high >= pos["take_profit_3"]:
                return pos["take_profit_3"], "take_profit_3"
            if pos.get("take_profit_2") and high >= pos["take_profit_2"]:
                return pos["take_profit_2"], "take_profit_2"
            if pos.get("take_profit_1") and high >= pos["take_profit_1"]:
                return pos["take_profit_1"], "take_profit_1"
        else:  # short
            if high >= pos["stop_loss"]:
                return pos["stop_loss"], "stop_loss"
            if pos.get("take_profit_3") and low <= pos["take_profit_3"]:
                return pos["take_profit_3"], "take_profit_3"
            if pos.get("take_profit_2") and low <= pos["take_profit_2"]:
                return pos["take_profit_2"], "take_profit_2"
            if pos.get("take_profit_1") and low <= pos["take_profit_1"]:
                return pos["take_profit_1"], "take_profit_1"

        return None, None

    def _close_position(self, pos: Dict, exit_price: float, reason: str, exit_time: str) -> BacktestTradeResult:
        entry = pos["entry_price"]
        qty = pos["quantity"]
        direction = pos["direction"]
        fee = exit_price * qty * (self.config.commission_percent / 100)

        if direction == "long":
            pnl = (exit_price - entry) * qty
        else:
            pnl = (entry - exit_price) * qty

        pnl_percent = (pnl / (entry * qty)) * 100

        return BacktestTradeResult(
            symbol=self.config.symbol,
            direction=direction,
            entry_price=entry,
            exit_price=exit_price,
            quantity=qty,
            entry_time=pos["entry_time"],
            exit_time=exit_time,
            stop_loss=pos["stop_loss"],
            take_profit=pos.get("take_profit_1"),
            pnl=round(pnl, 4),
            pnl_percent=round(pnl_percent, 3),
            fees=round(fee + pos.get("fee_paid", 0), 4),
            exit_reason=reason,
            indicators=pos.get("indicators", {}),
        )

    def _calculate_metrics(
        self,
        final_balance: float,
        trades: List[BacktestTradeResult],
        equity_curve: List[Dict]
    ) -> BacktestResult:
        """Calculate comprehensive performance metrics."""

        if not trades:
            return BacktestResult(
                strategy_name=self.config.strategy.name,
                symbol=self.config.symbol,
                timeframe=self.config.timeframe,
                start_date=self.config.start_date,
                end_date=self.config.end_date,
                initial_balance=self.config.initial_balance,
                final_balance=final_balance,
                total_return_percent=0,
                total_trades=0,
                winning_trades=0,
                losing_trades=0,
                win_rate=0,
                profit_factor=0,
                sharpe_ratio=0,
                sortino_ratio=0,
                calmar_ratio=0,
                max_drawdown_percent=0,
                max_drawdown_duration_days=0,
                avg_trade_duration_hours=0,
                avg_win=0,
                avg_loss=0,
                best_trade=0,
                worst_trade=0,
                total_fees=0,
                trades=[],
                equity_curve=equity_curve,
                drawdown_curve=[],
            )

        wins = [t for t in trades if t.pnl > 0]
        losses = [t for t in trades if t.pnl <= 0]
        total_return = ((final_balance - self.config.initial_balance) / self.config.initial_balance) * 100

        win_rate = len(wins) / len(trades) * 100

        gross_profit = sum(t.pnl for t in wins) if wins else 0
        gross_loss = abs(sum(t.pnl for t in losses)) if losses else 0
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else float("inf")

        # Equity curve analysis
        balances = [e["balance"] for e in equity_curve]
        returns = pd.Series(balances).pct_change().dropna()

        # Sharpe Ratio (annualized, assuming daily returns)
        if returns.std() > 0:
            sharpe = (returns.mean() / returns.std()) * np.sqrt(252)
        else:
            sharpe = 0.0

        # Sortino Ratio (only downside deviation)
        downside = returns[returns < 0]
        if len(downside) > 0 and downside.std() > 0:
            sortino = (returns.mean() / downside.std()) * np.sqrt(252)
        else:
            sortino = 0.0

        # Max Drawdown
        peak = self.config.initial_balance
        max_dd = 0.0
        drawdown_curve = []
        dd_start = None
        max_dd_duration = 0
        current_dd_start = None

        for i, eq in enumerate(equity_curve):
            b = eq["balance"]
            if b > peak:
                peak = b
                current_dd_start = None
            dd = (peak - b) / peak * 100 if peak > 0 else 0
            if dd > 0 and current_dd_start is None:
                current_dd_start = i
            if dd > max_dd:
                max_dd = dd
            drawdown_curve.append({"time": eq["time"], "drawdown": round(dd, 3)})

        calmar = total_return / max_dd if max_dd > 0 else 0.0

        return BacktestResult(
            strategy_name=self.config.strategy.name,
            symbol=self.config.symbol,
            timeframe=self.config.timeframe,
            start_date=self.config.start_date,
            end_date=self.config.end_date,
            initial_balance=self.config.initial_balance,
            final_balance=round(final_balance, 2),
            total_return_percent=round(total_return, 2),
            total_trades=len(trades),
            winning_trades=len(wins),
            losing_trades=len(losses),
            win_rate=round(win_rate, 2),
            profit_factor=round(profit_factor, 2),
            sharpe_ratio=round(sharpe, 3),
            sortino_ratio=round(sortino, 3),
            calmar_ratio=round(calmar, 3),
            max_drawdown_percent=round(max_dd, 2),
            max_drawdown_duration_days=max_dd_duration,
            avg_trade_duration_hours=0,
            avg_win=round(sum(t.pnl for t in wins) / len(wins), 2) if wins else 0,
            avg_loss=round(sum(t.pnl for t in losses) / len(losses), 2) if losses else 0,
            best_trade=round(max(t.pnl for t in trades), 2),
            worst_trade=round(min(t.pnl for t in trades), 2),
            total_fees=round(sum(t.fees for t in trades), 2),
            trades=trades,
            equity_curve=equity_curve,
            drawdown_curve=drawdown_curve,
        )
