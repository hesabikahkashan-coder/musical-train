"""
Binance Exchange Connector
Supports Spot and Futures trading with WebSocket streaming.
"""
import asyncio
import json
import time
from typing import Dict, List, Optional, Any, Callable
import ccxt.async_support as ccxt
import websockets
from ...core.logging import get_logger
from ..base_exchange import (
    BaseExchangeConnector, OrderRequest, OrderResult,
    Balance, Ticker, OHLCV, OrderSide, OrderType
)

logger = get_logger(__name__)


class BinanceConnector(BaseExchangeConnector):
    """
    Binance connector supporting Spot and Futures.
    Uses CCXT for REST API and native WebSocket for streaming.
    """

    TIMEFRAME_MAP = {
        "1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m",
        "1h": "1h", "4h": "4h", "1d": "1d", "1w": "1w"
    }

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        testnet: bool = False,
        futures: bool = False
    ):
        super().__init__(api_key, api_secret, testnet)
        self.futures = futures
        self._exchange: Optional[ccxt.binance] = None
        self._ws_connections: Dict[str, Any] = {}
        self._callbacks: Dict[str, Callable] = {}
        self._listen_key: Optional[str] = None
        self._listen_key_refresh_task = None

    async def connect(self) -> bool:
        """Initialize CCXT Binance connection."""
        try:
            exchange_config = {
                "apiKey": self.api_key,
                "secret": self.api_secret,
                "enableRateLimit": True,
                "options": {
                    "defaultType": "future" if self.futures else "spot",
                    "adjustForTimeDifference": True,
                },
            }

            if self.testnet:
                exchange_config["options"]["testnet"] = True
                exchange_config["urls"] = {
                    "api": {
                        "public": "https://testnet.binance.vision/api",
                        "private": "https://testnet.binance.vision/api",
                    }
                }

            self._exchange = ccxt.binance(exchange_config)
            await self._exchange.load_markets()
            
            # Test connection by fetching balance
            await self._exchange.fetch_balance()
            
            self._connected = True
            logger.info(f"Binance {'futures' if self.futures else 'spot'} connector connected")
            return True

        except ccxt.AuthenticationError as e:
            logger.error(f"Binance authentication failed: {e}")
            self._connected = False
            raise
        except Exception as e:
            logger.error(f"Binance connection failed: {e}")
            self._connected = False
            return False

    async def disconnect(self):
        """Close all connections."""
        if self._listen_key_refresh_task:
            self._listen_key_refresh_task.cancel()
        
        for ws_key, ws in self._ws_connections.items():
            try:
                await ws.close()
            except Exception:
                pass
        
        if self._exchange:
            await self._exchange.close()
        
        self._connected = False
        self._ws_connected = False
        logger.info("Binance connector disconnected")

    async def connect_websocket(self, symbols: List[str], callbacks: Dict[str, Any]):
        """Connect to Binance WebSocket streams."""
        self._callbacks = callbacks
        
        streams = []
        for symbol in symbols:
            # Convert to Binance format
            ws_symbol = symbol.replace("/", "").lower()
            streams.append(f"{ws_symbol}@ticker")
            streams.append(f"{ws_symbol}@kline_1m")
            streams.append(f"{ws_symbol}@depth5")

        stream_url = f"wss://stream.binance.com:9443/stream?streams={'/'.join(streams)}"
        
        asyncio.create_task(self._websocket_handler(stream_url))
        logger.info(f"Binance WebSocket connecting for {len(symbols)} symbols")

    async def _websocket_handler(self, url: str):
        """WebSocket message handler with auto-reconnect."""
        while True:
            try:
                async with websockets.connect(url, ping_interval=30, ping_timeout=10) as ws:
                    self._ws_connected = True
                    logger.info("Binance WebSocket connected")
                    
                    async for message in ws:
                        await self._process_ws_message(json.loads(message))
                        
            except websockets.ConnectionClosed as e:
                self._ws_connected = False
                logger.warning(f"Binance WebSocket closed: {e}. Reconnecting...")
                await asyncio.sleep(self._reconnect_delay)
            except Exception as e:
                self._ws_connected = False
                logger.error(f"Binance WebSocket error: {e}. Reconnecting...")
                await asyncio.sleep(self._reconnect_delay)

    async def _process_ws_message(self, message: Dict):
        """Process incoming WebSocket messages and dispatch to callbacks."""
        try:
            stream = message.get("stream", "")
            data = message.get("data", {})
            
            if "@ticker" in stream:
                if "on_ticker" in self._callbacks:
                    await self._callbacks["on_ticker"](self._parse_ticker(data))
            
            elif "@kline" in stream:
                if "on_kline" in self._callbacks:
                    await self._callbacks["on_kline"](self._parse_kline(data))
            
            elif "@depth" in stream:
                if "on_orderbook" in self._callbacks:
                    await self._callbacks["on_orderbook"](data)
                    
        except Exception as e:
            logger.error(f"Error processing WebSocket message: {e}")

    def _parse_ticker(self, data: Dict) -> Ticker:
        return Ticker(
            symbol=data.get("s", ""),
            bid=float(data.get("b", 0)),
            ask=float(data.get("a", 0)),
            last=float(data.get("c", 0)),
            volume=float(data.get("v", 0)),
            timestamp=int(data.get("T", 0))
        )

    def _parse_kline(self, data: Dict) -> Dict:
        k = data.get("k", {})
        return {
            "symbol": data.get("s", ""),
            "timeframe": k.get("i", ""),
            "open": float(k.get("o", 0)),
            "high": float(k.get("h", 0)),
            "low": float(k.get("l", 0)),
            "close": float(k.get("c", 0)),
            "volume": float(k.get("v", 0)),
            "is_closed": k.get("x", False),
            "timestamp": k.get("t", 0)
        }

    # ============================================================
    # Market Data
    # ============================================================

    async def get_ticker(self, symbol: str) -> Ticker:
        await self._ensure_connected()
        ticker = await self._exchange.fetch_ticker(symbol)
        return Ticker(
            symbol=symbol,
            bid=ticker["bid"],
            ask=ticker["ask"],
            last=ticker["last"],
            volume=ticker["baseVolume"],
            timestamp=ticker["timestamp"]
        )

    async def get_orderbook(self, symbol: str, depth: int = 20) -> Dict:
        await self._ensure_connected()
        return await self._exchange.fetch_order_book(symbol, depth)

    async def get_ohlcv(self, symbol: str, timeframe: str, limit: int = 500) -> List[OHLCV]:
        await self._ensure_connected()
        tf = self.TIMEFRAME_MAP.get(timeframe, "1h")
        raw = await self._exchange.fetch_ohlcv(symbol, tf, limit=limit)
        return [OHLCV(
            timestamp=candle[0],
            open=candle[1],
            high=candle[2],
            low=candle[3],
            close=candle[4],
            volume=candle[5]
        ) for candle in raw]

    async def get_balance(self) -> Dict[str, Balance]:
        await self._ensure_connected()
        raw = await self._exchange.fetch_balance()
        balances = {}
        for currency, data in raw["total"].items():
            if data > 0:
                balances[currency] = Balance(
                    currency=currency,
                    free=raw["free"].get(currency, 0),
                    used=raw["used"].get(currency, 0),
                    total=data
                )
        return balances

    async def get_positions(self) -> List[Dict]:
        if not self.futures:
            return []
        await self._ensure_connected()
        positions = await self._exchange.fetch_positions()
        return [p for p in positions if p["contracts"] > 0]

    # ============================================================
    # Order Management
    # ============================================================

    async def place_order(self, order: OrderRequest) -> OrderResult:
        """Place an order with full safety validation."""
        is_safe, message = self.validate_order_safety(order)
        if not is_safe:
            raise ValueError(f"Order safety check failed: {message}")

        await self._ensure_connected()

        params = {}
        if order.stop_price:
            params["stopPrice"] = order.stop_price
        if order.client_order_id:
            params["newClientOrderId"] = order.client_order_id
        if order.time_in_force and order.order_type == OrderType.LIMIT:
            params["timeInForce"] = order.time_in_force
        if self.futures and order.reduce_only:
            params["reduceOnly"] = True

        try:
            result = await self._exchange.create_order(
                symbol=order.symbol,
                type=order.order_type.value,
                side=order.side.value,
                amount=order.quantity,
                price=order.price,
                params=params
            )

            return OrderResult(
                exchange_order_id=str(result["id"]),
                symbol=order.symbol,
                side=order.side.value,
                order_type=order.order_type.value,
                status=result["status"],
                price=result.get("price"),
                quantity=result["amount"],
                filled_quantity=result.get("filled", 0),
                average_fill_price=result.get("average"),
                fee=result.get("fee", {}).get("cost", 0) if result.get("fee") else 0,
                fee_currency=result.get("fee", {}).get("currency", "USDT") if result.get("fee") else "USDT",
                created_at=str(result.get("datetime", "")),
                raw_response=result
            )

        except ccxt.InsufficientFunds as e:
            logger.error(f"Insufficient funds: {e}")
            raise
        except ccxt.InvalidOrder as e:
            logger.error(f"Invalid order: {e}")
            raise
        except ccxt.RateLimitExceeded as e:
            await self.handle_rate_limit()
            raise

    async def cancel_order(self, order_id: str, symbol: str) -> bool:
        await self._ensure_connected()
        try:
            await self._exchange.cancel_order(order_id, symbol)
            return True
        except ccxt.OrderNotFound:
            logger.warning(f"Order {order_id} not found for cancellation")
            return False

    async def get_order(self, order_id: str, symbol: str) -> Dict:
        await self._ensure_connected()
        return await self._exchange.fetch_order(order_id, symbol)

    async def get_open_orders(self, symbol: Optional[str] = None) -> List[Dict]:
        await self._ensure_connected()
        return await self._exchange.fetch_open_orders(symbol)

    async def handle_rate_limit(self, retry_after: int = None):
        wait_time = retry_after or 60
        logger.warning(f"Rate limit hit. Waiting {wait_time}s...")
        await asyncio.sleep(wait_time)

    async def _ensure_connected(self):
        if not self._connected:
            await self.reconnect_with_backoff()
        if not self._connected:
            raise ConnectionError("Failed to connect to Binance")
