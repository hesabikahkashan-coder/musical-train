"""Strategy models."""
from sqlalchemy import Column, String, Boolean, Float, ForeignKey, Enum, Text, Integer
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
import enum
from .base import Base, TimestampMixin, UUIDMixin


class StrategyType(str, enum.Enum):
    SCALPING = "scalping"
    SWING = "swing"
    TREND_FOLLOWING = "trend_following"
    GRID = "grid"
    DCA = "dca"
    BREAKOUT = "breakout"
    MEAN_REVERSION = "mean_reversion"


class StrategyStatus(str, enum.Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    STOPPED = "stopped"
    BACKTESTING = "backtesting"


class Strategy(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "strategies"

    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    strategy_type = Column(Enum(StrategyType), nullable=False)
    status = Column(Enum(StrategyStatus), default=StrategyStatus.PAUSED, nullable=False, index=True)

    # Execution settings
    exchange = Column(String(50), nullable=False)
    symbols = Column(JSONB, nullable=False)  # List of symbols to trade
    timeframe = Column(String(10), default="1h")  # 1m, 5m, 15m, 1h, 4h, 1d, 1w

    # Risk settings per strategy
    max_open_trades = Column(Integer, default=3)
    risk_per_trade_percent = Column(Float, default=1.0)
    stop_loss_percent = Column(Float)
    take_profit_percent = Column(Float)
    use_trailing_stop = Column(Boolean, default=False)
    trailing_stop_percent = Column(Float)

    # Strategy-specific parameters
    parameters = Column(JSONB, default={})  # Strategy-specific config

    # Performance tracking
    total_trades = Column(Integer, default=0)
    winning_trades = Column(Integer, default=0)
    losing_trades = Column(Integer, default=0)
    total_pnl = Column(Float, default=0.0)
    win_rate = Column(Float, default=0.0)
    sharpe_ratio = Column(Float)
    max_drawdown = Column(Float, default=0.0)

    # Relationships
    user = relationship("User", back_populates="strategies")
    trades = relationship("Trade", back_populates="strategy")
    backtests = relationship("Backtest", back_populates="strategy")

    def __repr__(self):
        return f"<Strategy(name={self.name}, type={self.strategy_type}, status={self.status})>"


class StrategyConfig(Base, UUIDMixin, TimestampMixin):
    """Version-controlled strategy configurations."""
    __tablename__ = "strategy_configs"

    strategy_id = Column(UUID(as_uuid=True), ForeignKey("strategies.id", ondelete="CASCADE"), nullable=False)
    version = Column(Integer, nullable=False)
    config = Column(JSONB, nullable=False)
    is_active = Column(Boolean, default=True)
    notes = Column(Text)
