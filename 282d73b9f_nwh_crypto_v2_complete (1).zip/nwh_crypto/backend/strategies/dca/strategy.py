"""
DCA (Dollar Cost Averaging) Strategy
Systematic buying at regular intervals or price dips.
"""
from typing import List, Dict, Optional
from dataclasses import dataclass, field
from datetime import datetime, timezone
from ..base_strategy import BaseStrategy, StrategySignal, SignalType, StrategyConfig
from ..technical_indicators import TechnicalIndicators
from ...core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class DCAConfig(StrategyConfig):
    base_order_size: float = 100.0      # Base order in USD
    safety_order_size: float = 200.0    # Safety order in USD
    max_safety_orders: int = 5
    price_deviation_percent: float = 2.0  # Trigger safety order every X% drop
    take_profit_percent: float = 2.0
    cooldown_hours: float = 4.0          # Hours between base orders


class DCAStrategy(BaseStrategy):
    """
    DCA Strategy with Safety Orders (similar to 3Commas DCA bot).
    
    Opens base order, then adds safety orders on price drops.
    Exits when average entry price rises to TP.
    """

    def __init__(self, config: Optional[DCAConfig] = None):
        if config is None:
            config = DCAConfig(
                name="DCA Bot",
                symbols=["BTC/USDT"],
                timeframe="1h"
            )
        super().__init__(config)
        self.dca_config: DCAConfig = config
        self._dca_state: Dict[str, Dict] = {}  # symbol -> dca state

    def get_required_candles(self) -> int:
        return 20

    async def analyze(self, symbol: str, candles: List[Dict]) -> StrategySignal:
        try:
            df = TechnicalIndicators.to_dataframe(candles)
            current_price = df["close"].iloc[-1]

            state = self._dca_state.get(symbol, {
                "active": False,
                "base_price": None,
                "avg_price": None,
                "safety_orders_placed": 0,
                "total_qty": 0.0,
                "total_cost": 0.0,
                "last_order_time": None,
            })

            rsi = TechnicalIndicators.rsi(df, 14)
            indicators = {"rsi": rsi.value, "current_price": current_price}

            if not state["active"]:
                # Only open new DCA if RSI is not extremely overbought
                if rsi.value < 70:
                    self._dca_state[symbol] = {
                        "active": True,
                        "base_price": current_price,
                        "avg_price": current_price,
                        "safety_orders_placed": 0,
                        "total_qty": 0.0,
                        "total_cost": 0.0,
                        "last_order_time": datetime.now(timezone.utc).isoformat(),
                    }

                    sl = current_price * (1 - (self.dca_config.max_safety_orders * self.dca_config.price_deviation_percent / 100 + 2))
                    tp = current_price * (1 + self.dca_config.take_profit_percent / 100)

                    return StrategySignal(
                        signal_type=SignalType.BUY, symbol=symbol,
                        timeframe=self.config.timeframe, confidence=0.7,
                        entry_price=current_price,
                        stop_loss=round(sl, 6),
                        take_profit_1=round(tp, 6),
                        reason=f"DCA base order | RSI={rsi.value:.1f}",
                        indicators=indicators
                    )

            elif state["active"] and state["safety_orders_placed"] < self.dca_config.max_safety_orders:
                # Check if price dropped enough for safety order
                next_safety_price = state["base_price"] * (
                    1 - ((state["safety_orders_placed"] + 1) * self.dca_config.price_deviation_percent / 100)
                )
                if current_price <= next_safety_price:
                    state["safety_orders_placed"] += 1
                    self._dca_state[symbol] = state

                    sl = current_price * 0.92  # 8% below current
                    tp = state["avg_price"] * (1 + self.dca_config.take_profit_percent / 100)

                    return StrategySignal(
                        signal_type=SignalType.BUY, symbol=symbol,
                        timeframe=self.config.timeframe, confidence=0.65,
                        entry_price=current_price,
                        stop_loss=round(sl, 6),
                        take_profit_1=round(tp, 6),
                        reason=f"DCA safety order #{state['safety_orders_placed']}",
                        indicators=indicators
                    )

            return StrategySignal(
                signal_type=SignalType.HOLD, symbol=symbol,
                timeframe=self.config.timeframe, confidence=0.0,
                reason="DCA: waiting for conditions", indicators=indicators
            )

        except Exception as e:
            logger.error(f"DCA analysis error: {e}")
            return StrategySignal(signal_type=SignalType.HOLD, symbol=symbol,
                                  timeframe=self.config.timeframe, confidence=0.0, reason=str(e))
